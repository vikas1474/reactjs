import React, { Component } from 'react';
import './App.css';

class ProductList extends Component {

  constructor(){
    super();    
  }
  

  render() {
    return (
      <div className="row">        
          {
             this.props.product.map((product)=>{
           return (
            <div className="col-md-3">
              <div className="block">
                <p><img src={product.image}/></p>
                <h4>{product.name}</h4>
                <p><b>{product.price}</b></p>
              </div>
            </div>
            )
           })
          }         
      </div>
    );
  }
}

export default ProductList;
