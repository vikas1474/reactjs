const initialState={
      data:[]
    }

const appReducer = (state = initialState,action) =>{
	console.log(action);
	if(action.type == 'GETDATA'){
		return {
			...state,
			data:action.payload
		}
	}	
	else{
		return state;
	}
	
}    

export default appReducer;

