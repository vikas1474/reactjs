
const initialState1={
      name:['java']
}

const filterReducer = (state=initialState1,action) =>{
	console.log(action);
	return state;
	
}    

export default filterReducer;

