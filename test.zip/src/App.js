import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import Facet from './facets';
import ProductList from './product_list';

import {connect} from 'react-redux';
import {loadData} from './actions/action';
class App extends Component {

    componentDidMount(){
      this.props.loadData();
    }

  // getData(){
  //   fetch('https://ecommerce-3ad3f.firebaseio.com/productdetails.json').then((res)=>{
  //     return res.json();
  //   }).then((data)=>{   
  //     let productData=[];
  //     for(var i in data) {
  //       data[i]["id"]=i;
  //       productData.push(data[i])  
  //     }
  //     this.setState({
  //        data:productData 
  //     })
  //   })
  // }

  // componentWillMount(){
  //     this.getData();
  // }

  // filterProductonCategory = (category,bool)=>{
  //     let filter=[...this.state.filter];
  //     let remove;
  //     if(bool == true){
  //       filter.push(category);
  //     }
  //     else{
  //       let index=filter.indexOf(category);
  //       remove=filter.splice(index,1);
  //       console.log(filter);        
  //     }
  //     this.setState({
  //       filter:filter
  //     })
  // }

  render() {
//    const products=this.props.loadData();
    return (
      <div className="container">
        <div className="row">
          <div className="left-panel col-md-2">
          </div>
          <div className="right-panel col-md-9">
            <ProductList product={this.props.data}/>            
          </div>
        </div>
      </div>
    );
  }
}


const mapStateToProps = (state) =>({
    data:state.data
})

const mapDispatchToProps = (dispatch) =>{
  return{
    loadData: () => dispatch(loadData())
  }
}

export default connect(mapStateToProps,mapDispatchToProps)(App);
