
export function filterData1(){
	return(dispatch)=>{
			dispatch(filterData('jain'));
	}
}


export function filterData(data){
	return{
        type:"FILTER",
        payload:data
	}
}
